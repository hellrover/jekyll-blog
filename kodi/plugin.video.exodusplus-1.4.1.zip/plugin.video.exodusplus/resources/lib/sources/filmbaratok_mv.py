# -*- coding: utf-8 -*-

import re,urllib,urlparse
from resources.lib.modules import control
from resources.lib.modules import client
from resources.lib.modules import cache


class source:
    def __init__(self):
        self.domains = ['filmbaratok.com']
        self.base_link = 'http://filmbaratok.com'
        self.user = control.setting('filmbaratok.user')
        self.password = control.setting('filmbaratok.pass')

    def movie(self, imdb, title, year):
        try:
            if (self.user == '' or self.password == ''): raise Exception()
            
            t = 'http://www.imdb.com/title/%s' % imdb
            t = client.request(t, headers={'Accept-Language':'hu-HU'})
            t = client.parseDOM(t, 'title')[0]
            originaltitle = re.sub('(?:\(|\s)\d{4}.+', '', t).strip()
            ot = originaltitle.replace(' ', '+')
            
            query = '/search/?search_query=' + ot.encode('utf-8') + '&tax_release-year%5B%5D=' + year
            query = urlparse.urljoin(self.base_link, query)

            r = client.request(query)
            r = client.parseDOM(r, 'div', attrs = {'class': 'resultado'})

            for item in r:
                url = client.parseDOM(item, 'a', ret='href')[0]
                url = client.replaceHTMLCodes(url)
                url = url.encode('utf-8')
                src = client.request(url)
                imdb_id = re.compile('imdb.com/title/(tt[0-9]+)/').findall(src)[0]
                if imdb_id == imdb:
                    return url
                    break
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []

            if url == None: return sources
            
            locDict = [(i.rsplit('.', 1)[0], i) for i in hostDict]

            login = urlparse.urljoin(self.base_link, '/login/')

            post = urllib.urlencode({'log': self.user, 'pwd': self.password, 'submit': 'Belépés', 'redirect_to': 'http://filmbaratok.com'})

            cookie = cache.get(self.get_cookie, 5, login, post)

            headers = {'Referer': url, 'Cookie': cookie}

            query = urlparse.urljoin(self.base_link, '/ajax/?q=url-list')
            
            r = client.request(query, headers=headers)
            r = r.decode('unicode-escape').split('<li>')

            for i in r:
                try:
                    host = client.parseDOM(i, 'span', attrs = {'class': 'op'})[0].split('<')[0].rsplit('.', 1)[0].lower()
                    host = [x[1] for x in locDict if host == x[0]][0]
                    if not host in hostDict: raise Exception()
                    host = client.replaceHTMLCodes(host)
                    host = host.encode('utf-8')
                    
                    item = re.compile('click&0=([0-9]+).+?Nyelv.+?span>\s?(.+?)<.+?title.+?span>\s?(.+?)<').findall(i)[0]
                    if 'DVD' in item[2]: quality = 'SD'
                    elif 'Mozis' in item[2]: quality = 'CAM'
                    else: quality = 'SD'
                    if 'szinkron' in item[1]: lang = '[COLOR green]SZINKRON[/COLOR]'
                    elif 'magyar felirat' in item[1]: lang = 'FELIRAT'
                    else: lang = 'NF'
                    query = urlparse.urljoin(self.base_link, '/online-video/?id=%s' % (item[0]))
                    url = client.replaceHTMLCodes(query)
                    url = url.encode('utf-8')
    
                    sources.append({'source': host, 'quality': quality, 'lang': lang, 'provider': 'Filmbaratok', 'url': url, 'direct': False, 'debridonly': False})
                except:
                    pass

            return sources
        except:
            return sources


    def resolve(self, url):
        try:
            login = urlparse.urljoin(self.base_link, '/login/')
            post = urllib.urlencode({'log': self.user, 'pwd': self.password, 'submit': 'Belépés', 'redirect_to': 'http://filmbaratok.com'})
            cookie = cache.get(self.get_cookie, 5, login, post)
            headers = {'Referer': url, 'Cookie': cookie}
            
            src = client.request(url, headers=headers)
            try: url = client.parseDOM(src, 'iframe', ret='src')[-1]
            except: url = client.parseDOM(src, 'IFRAME', ret='SRC')[-1]
            return url
        except:
            return
        
    def get_cookie(self, login, post):
        return client.request(login, post=post, output='cookie', close=False)
    