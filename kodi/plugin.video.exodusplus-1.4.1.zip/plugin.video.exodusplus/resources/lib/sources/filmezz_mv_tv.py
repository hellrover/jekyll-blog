# -*- coding: utf-8 -*-

import re,urllib,urllib2,urlparse
from resources.lib.modules import cleantitle
from resources.lib.modules import client


class source:
    def __init__(self):
        self.domains = ['filmezz.eu']
        self.base_link = 'http://filmezz.eu/'
        self.search_link = 'http://filmezz.eu/kereses.php?'
        self.play_link = 'http://filmezz.eu/linkek.php?id=%s'

    def movie(self, imdb, title, year):
        try:
            url = None
            result = None
            
            title = title.replace(' ','+')

            try:
                result = client.request(self.search_link + 's=' + title + '&e=' + year + '&t=1')
                if 'nincs találat!' in result: raise Exception()
            except:
                return

            result = client.parseDOM(result, 'div', attrs={'class': 'boxcont'})           
            result = result[0].replace('\n','')
            result = re.compile('a href="(.+?)".+?<b>(.+?)</').findall(result)

            for a, b in result:
                query = urlparse.urljoin(self.base_link, a)
                query = client.replaceHTMLCodes(query)
                query = query.encode('utf-8')
                page_src = client.request(query)
                imdb_id = None
                if 'imdb.com/title/tt' in page_src:                             
                    imdb_id = re.compile('imdb.com/title/(tt[0-9]+)/').findall(page_src)[0]
                if imdb_id == imdb:
                    url = client.replaceHTMLCodes(query)
                    url = url.encode('utf-8')
                    return url
        except:
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return
        
    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url == None: return            
            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']    
            
            title = title.replace(' ','+')
            
            try:
                result = client.request(self.search_link + 's=' + title + '&t=2')
                if 'nincs találat!' in result: raise Exception()
            except:
                return
                
            result = client.parseDOM(result, 'div', attrs={'class': 'boxcont'})[0]
            result = result.split('<div style="float:left; border')
            result = [i for i in result if '-' + season + '-evad' in i]

            #result = re.compile('<a href="?\'?([^"\'>]*).+?center>.+?\s([0-9]+)\..+?vad').findall(result)
            for i in result:
                try:
                    query = client.parseDOM(i, 'a', ret='href')[0]
                    query = urlparse.urljoin(self.base_link, query)
                    query = client.replaceHTMLCodes(query)
                    query = query.encode('utf-8')
                    page_src = client.request(query)
                    if 'imdb.com/title/tt' in page_src:                             
                        imdb_id = re.compile('imdb.com/title/(tt[0-9]+)/').findall(page_src)[0]
                        if imdb_id == imdb:
                            url = query
                except: pass
            
            if not url.startswith('http'): raise Exception()
            url = urlparse.urljoin(self.base_link, url)
            result = client.request(url)
            result = result.replace('\n','')
            result = client.parseDOM(result, 'table', attrs = {'id': 'forrlist'})
            result = result[0].split('<tr>')
            result = [i for i in result if 'epiz' in i]
            links = [i for i in result if re.compile('\s?([0-9]+)\. epiz').findall(i)[0] == episode]
            ep_url = links
            return ep_url
        except:
            return
    

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []

            if url == None: return sources
            if isinstance(url, basestring):
                url = urlparse.urljoin(self.base_link, url)

                result = client.request(url)
                result = result.replace('\n','')

                links = client.parseDOM(result, 'table', attrs = {'id': 'forrlist'})
                links = links[0].split('<tr>')
            else:
                links = url
            
            locDict = [(i.rsplit('.', 1)[0], i) for i in hostDict]
            
            for i in links:
                try:
                    host = i.split('top">')[2].split('<')[0].strip().rsplit('.', 1)[0].lower().replace('vidtome', 'vidto')
                    try: host = host.split('(')[0].strip()
                    except: pass
                    host = [x[1] for x in locDict if host == x[0]][0]
                    if not host in hostDict: raise Exception()
                    host = client.replaceHTMLCodes(host)
                    host = host.encode('utf-8')
                    url = client.parseDOM(i, 'a', ret='id')[0]
                    url = self.play_link % urllib.quote_plus(url)
                    url = client.replaceHTMLCodes(url)
                    url = url.encode('utf-8')
                    quality = re.findall('qual/([0-9])\.', i)[0]
                    if quality == '1': quality = 'CAM'
                    elif quality == '2' or quality == '3': quality = 'SD'                    
                    else: quality = 'SD'
                    lang = re.findall('lang/([0-9])\.', i)[0]
                    if lang == '2': lang = 'FELIRAT'
                    elif lang == '3': lang = '[COLOR green]SZINKRON[/COLOR]'
                    else: lang == 'NF'
                    sources.append({'source': host, 'quality': quality, 'lang': lang, 'provider': 'Filmezz', 'url': url, 'direct': False, 'debridonly': False})
                except:
                    pass

            return sources
        except:
            return sources


    def resolve(self, url):
        location = ''
        try:
            r = client.request(url, output='headers', redirect=False).headers
            try: location = [i.replace('Location:', '').strip() for i in r if 'Location:' in i][0]
            except: location = client.request(url)
            if not location.startswith('http'):
                try: location = client.parseDOM(location, 'iframe', ret='src')[0]
                except: location = client.parseDOM(location, 'IFRAME', ret='SRC')[0]
            if not location.startswith('http'): raise Exception()
            url = client.replaceHTMLCodes(location)
            url = re.sub(r'^"|"$', '', url)
            try: url = url.encode('utf-8')
            except: pass
            return url
        except: 
            return
