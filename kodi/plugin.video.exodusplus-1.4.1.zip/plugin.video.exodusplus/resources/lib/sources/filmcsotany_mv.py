# -*- coding: utf-8 -*-

'''
    Exodus Add-on
    Copyright (C) 2016 Exodus

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import re,urllib,urllib2,urlparse,json

from resources.lib.modules import client, cache


class source:
    def __init__(self):
        self.domains = ['filmcsotany.net']
        self.base_link = 'http://www.filmcsotany.net/'
        self.search_link = 'http://www.filmcsotany.net/_controllers/siteHandler.php'
        self.user_agent = cache.get(client.randomagent, 1)

    def movie(self, imdb, title, year):
        try:
            url = None           
            
            headers = {'User-Agent': self.user_agent}
            post = {'command': 'siteDTSearchV2', 'A': 'true', 'title': title, 'year': year, 'lang': '1', 'cat': '0'}
            post = urllib.urlencode(post)
            result = client.request(self.search_link, post=post, headers=headers)
            if not 'film_box_title' in result: raise Exception()
                       
            result = json.loads(result)['content']
            result = client.parseDOM(result, 'a', ret='href')
            for a in result:
                query = client.replaceHTMLCodes(a)
                query = query.encode('utf-8')
                page_src = client.request(query, headers=headers)
                try: page_src = page_src.decode('iso-8859-1').encode('utf8')
                except: pass
                if 'imdb.com/title/tt' in page_src:                                                 
                    imdb_id = re.compile('imdb.com/title/(tt[0-9]+)').findall(page_src)[0]
                    if imdb_id == imdb:
                        url = client.parseDOM(page_src, 'div', attrs={'class': 'linkholder '})[0], a
                        return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url == None: return sources
            location = url[1]
            result = url[0].replace('\n','')
            result = re.compile('_images/([^\.]+).+?<div>([^<]+).+?lid=([^\']+)').findall(result)
            
            locDict = [(i.rsplit('.', 1)[0], i) for i in hostDict]
                            
            for i in result:
                try:     
                    host = i[1].split()[0].rsplit('.', 1)[0].strip().lower()
                    try: host = host.split('(')[0].strip()
                    except: pass
                    host = [x[1] for x in locDict if host == x[0]][0]
                    if not host in hostDict: raise Exception()
                    host = client.replaceHTMLCodes(host)
                    host = host.encode('utf-8')
                    if 'magyar-m' in i[0]: lang = '[COLOR green]SZINKRON[/COLOR]'
                    elif 'magyar_felirat' in i[0]: lang = 'FELIRAT'
                    else: lang = 'NF'
                    url = i[2].strip()
                    url = url.encode('utf-8')
                    sources.append({'source': host, 'quality': 'SD', 'lang': lang, 'provider': 'Filmcsotany', 'url': (url, location), 'direct': False, 'debridonly': False})
                except:
                    pass
            return sources
        except:
            return sources


    def resolve(self, url):
        try:
            opener = urllib2.build_opener(NoRedirection)
            opener.addheaders = [('Referer', 'http://cur.lv/ntop.php?s='), 
                                ('User-Agent', self.user_agent)]

            url = opener.open('http://www.filmcsotany.net/linkek/coinlink.php?lid=' + url[0]).info().getheader('Location')

            url = client.replaceHTMLCodes(url)
            if 'filmcsotany' in url: raise Exception()
            url = url.encode('utf-8')
            return url
        except:
            return
        

class NoRedirection(urllib2.HTTPErrorProcessor):
        def http_response(self, request, response):
            return response