# -*- coding: utf-8 -*-

import re,urllib,urllib2,urlparse,base64,datetime

from resources.lib.modules import cleantitle
from resources.lib.modules import client


class source:
    def __init__(self):
        self.domains = ['mozicsillag.cc']
        self.base_link = 'http://mozicsillag.cc/'
        self.search_link = 'http://mozicsillag.cc/kereses/'
        self.host_link = 'http://filmbirodalmak.com/'

    def movie(self, imdb, title, year):
        try:    
            years = [str(int(year)-1), str(int(year)+1)]
            
            title = title.replace(' ','+')

            t = 'http://www.imdb.com/title/%s' % imdb
            t = client.request(t, headers={'Accept-Language':'hu-HU'})
            t = client.parseDOM(t, 'title')[0]
            originaltitle = re.sub('(?:\(|\s)\d{4}.+', '', t).strip().replace(' ', '+')
            result = None
            
            try:
                search_url = 'search_term=' + originaltitle.encode('utf-8') + '&search_type=1&search_where=0&search_rating_start=1&search_rating_end=10&search_year_from=' + years[0] + '&search_year_to=' + years[1]
                search_url = base64.b64encode(search_url)
                query = self.search_link + search_url
                result = client.request(query)
                if 'Nem ezeket keresed?' in result: result = None
            except:
                pass
            
            try:
                if not result == None: raise Exception()
                search_url = 'search_term=' + title + '&search_type=1&search_where=0&search_rating_start=1&search_rating_end=10&search_year_from=' + years[0] + '&search_year_to=' + years[1]
                search_url = base64.b64encode(search_url)
                query = self.search_link + search_url
                result = client.request(query)
                if 'Nem ezeket keresed?' in result: return
            except:
                pass
                       
            result = client.parseDOM(result, 'ul', attrs={'class': 'small-block-grid-2 medium-block-grid-4 large-block-grid-5 enable-hover-link'})[0]
            result = client.parseDOM(result, 'a', ret='href')                        
            for a in result:
                query = client.replaceHTMLCodes(a)
                page_src = client.request(query)
                page_src = page_src.replace('\n','')
                if 'imdb.com/title/tt' in page_src:                                                 
                    imdb_id = re.compile('imdb.com/title/(tt[0-9]+)').findall(page_src)[0]
                    if imdb_id == imdb:
                        url = client.parseDOM(page_src, 'div', attrs={'class': 'small-12 medium-7 small-centered columns'})[0]
                        url = client.parseDOM(url, 'a', ret='href')[0]
                        url = client.replaceHTMLCodes(url)
                        url = url.encode('utf-8')
            
            result = client.request(url)                                                                                          
            result = result.replace('\n','')
            url = client.parseDOM(result, 'div', attrs={'class': 'content'})[0]
            return url
        except:
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, year):        
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return
 
    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url == None: return
            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']            
            title = title.replace(' ','+')
            current_year = datetime.datetime.now().strftime("%Y")
            epiz = 'Epizód ' + episode + '<'
            
            try:
                search_url = 'search_term=' + title + '&search_type=2&search_where=0&search_rating_start=1&search_rating_end=10&search_year_from=1900&search_year_to=' + current_year
                search_url = base64.b64encode(search_url)
                query = self.search_link + search_url
                result = client.request(query)
                if 'Nem ezeket keresed?' in result: raise Exception()
            except:
                return
            
            result = client.parseDOM(result, 'ul', attrs={'class': 'small-block-grid-2 medium-block-grid-4 large-block-grid-5 enable-hover-link'})[0]
            result = client.parseDOM(result, 'a', ret='href')
            for i in result:
                if '/' + season + '-evad' in i:
                    query = client.replaceHTMLCodes(i)
                    page_src = client.request(query)
                    page_src = page_src.replace('\n','')
                    if 'imdb.com/title/tt' in page_src:                                                 
                        imdb_id = re.compile('imdb.com/title/(tt[0-9]+)').findall(page_src)[0]
                        if imdb_id == imdb:
                            url = client.parseDOM(page_src, 'div', attrs={'class': 'small-12 medium-7 small-centered columns'})[0]
                            url = client.parseDOM(url, 'a', ret='href')[0]
                            url = client.replaceHTMLCodes(url)
                            url = url.encode('utf-8')
                    
            result = client.request(url)                                                                                          
            result = result.replace('\n','')
            result = client.parseDOM(result, 'div', attrs = {'class': 'accordion-episodes'})  
            ep_url = [i for i in result if epiz.decode('utf-8') in i][0]
            return ep_url
        except:
            return
    

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url == None: return sources
            
            result = re.compile('title=(.+?)>.+?flags/(.+?)\..+?(watch.+?)(?:\'|")').findall(url)
            filter = []
            filter += [i for i in result if i[1] == 'HU' and not 'CAM' in i[0]]            
            filter += [i for i in result if i[1] == 'HU' and 'CAM' in i[0]]
            filter += [i for i in result if i[1] == 'EN_HU' or i[1] == 'SUB_HU']
            filter += [i for i in result if i[1] == 'EN' or i[1] =='SUB_EN' or i[1] == 'MAS']
            
            locDict = [(i.rsplit('.', 1)[0], i) for i in hostDict]         
            
            for i in filter:
                try:  
                    host = i[0].split(' -')[0].replace('\'','').replace('"','').strip().lower()
                    host = [x[1] for x in locDict if host == x[0]][0]
                    if not host in hostDict: raise Exception()
                    host = client.replaceHTMLCodes(host)
                    host = host.encode('utf-8')
                    if 'CAM' in i[0]: quality = 'CAM'
                    #elif 'HD' in i[0]: quality = 'HD'               
                    else: quality = 'SD'
                    if i[1] == 'HU': lang = '[COLOR green]SZINKRON[/COLOR]'
                    elif i[1] == 'EN_HU' or i[1] == 'SUB_HU': lang = 'FELIRAT'
                    else: lang = 'NF'
                    url = self.host_link + i[2]
                    url = client.replaceHTMLCodes(url)
                    url = url.encode('utf-8')
                    sources.append({'source': host, 'quality': quality, 'lang': lang, 'provider': 'Mozicsillag', 'url': url, 'direct': False, 'debridonly': False})
                except:
                    pass
            return sources
        except:
            return sources


    def resolve(self, url):
        try:
            result = client.request(url)
            if 'FilmBirodalom' in result:
                url = client.parseDOM(result, 'div', attrs={'class': 'content'})[0]
                url = client.parseDOM(url, 'a', ret='href')[0]
            else:
                url = client.request(url, output='geturl')
            url = client.replaceHTMLCodes(url)
            url = url.encode('utf-8')
            return url
        except:
            return


