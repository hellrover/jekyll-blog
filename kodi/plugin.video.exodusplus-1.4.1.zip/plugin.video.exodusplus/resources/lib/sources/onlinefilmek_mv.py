# -*- coding: utf-8 -*-

import re,urllib,urllib2,urlparse,base64,datetime

from resources.lib.modules import cleantitle
from resources.lib.modules import client


class source:
    def __init__(self):
        self.domains = ['online-filmek.tv']
        self.base_link = 'http://online-filmek.tv/'
        self.search_link = 'http://online-filmek.tv/kereses.php?'

    def movie(self, imdb, title, year):
        try:
            url = None              
            years = [str(int(year)-1), str(int(year)+1)] 
            
            t = 'http://www.imdb.com/title/%s' % imdb
            t = client.request(t, headers={'Accept-Language':'hu-HU'})
            t = client.parseDOM(t, 'title')[0]
            originaltitle = re.sub('(?:\(|\s)\d{4}.+', '', t).strip()
            title = originaltitle.encode('iso-8859-2')
            try:
                query = urllib.urlencode({'kereses': title, 'min_ev': years[0], 'max_ev': years[1]})
                query = self.search_link + query
                result = client.request(query)
                if 'Nincs tal\xe1lat!' in result: raise Exception()
            except:
                return

            result = result.decode('iso-8859-1').encode('utf-8')
            result = client.parseDOM(result, 'div', attrs={'class': 'thumbnail-container'})
            for a in result:
                try:
                    title2 = client.parseDOM(a, 'span', attrs={'class': 'title-text'})[0].strip()
                    try: title2 = re.sub('(?:\(|\s)\d{4}.+', '', title2).strip()
                    except: pass
                    title2 = title2.encode('iso-8859-1')
                    if cleantitle.get(title).replace('!', '') == cleantitle.get(title2).replace('!', ''):
                            url = client.parseDOM(a, 'a', ret='href')[0]
                            url = client.replaceHTMLCodes(url)
                            url = url.encode('utf-8')
                            return url
                except:
                    pass
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url == None: return sources
            
            result = client.request(url)
            result = result.decode('iso-8859-1').encode('utf-8')
            result = result.split('glyphicon-upload')[1].split('<script>')[0]
            url = client.parseDOM(result, 'a', ret='href')[0]
            result = client.request(url)
            result = result.replace('\n','')
            result = re.compile('<tr>.+?class="(.+?)".+?div>(.+?)<.+?<b>(.+?)<.+?href="(.+?)"').findall(result)
            
            locDict = [(i.rsplit('.', 1)[0], i) for i in hostDict]
                            
            for i in result:
                try:
                    host = i[2].split()[0].rsplit('.', 1)[0].strip().lower()
                    host = [x[1] for x in locDict if host == x[0]][0]
                    if not host in hostDict: raise Exception()
                    host = client.replaceHTMLCodes(host)
                    host = host.encode('utf-8')
                    if  i[1] == 'Kiv\xe1l\xf3' or i[1] == 'J\xf3': quality = 'SD'
                    elif i[1] == 'Kamer\xe1s': quality = 'CAM'                    
                    else: quality = 'SD'
                    if i[0] == 'kep-magyar_szinkron': lang = '[COLOR green]SZINKRON[/COLOR]'
                    elif i[0] == 'kep-magyar_feirat': lang = 'FELIRAT'
                    else: lang = 'NF'
                    url = client.replaceHTMLCodes(i[3])
                    url = url.encode('utf-8')  
                    sources.append({'source': host, 'quality': quality, 'lang': lang, 'provider': 'Onlinefilmek', 'url': url, 'direct': False, 'debridonly': False})
                except:
                    pass
            return sources
        except:
            return sources


    def resolve(self, url):
        try:
            result = client.request(url)
            try: url = client.parseDOM(result, 'iframe', ret='src')[0]
            except: url = client.parseDOM(result, 'IFRAME', ret='SRC')[0]
            url = client.replaceHTMLCodes(url)
            url = url.encode('utf-8')
            return url
        except:
            return
