# -*- coding: utf-8 -*-

'''
    Exodus Add-on
    Copyright (C) 2016 Exodus

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import re,urllib,urllib2,urlparse

from resources.lib.modules import client


class source:
    def __init__(self):
        self.domains = ['cinemalive.hu']
        self.base_link = 'http://www.cinemalive.hu/'
        self.search_link = 'http://www.cinemalive.hu/filmek/'

    def movie(self, imdb, title, year):
        try:         
            years = [str(int(year)-1), str(int(year)+1)]
            
            t = 'http://www.imdb.com/title/%s' % imdb
            t = client.request(t, headers={'Accept-Language':'hu-HU'})
            t = client.parseDOM(t, 'title')[0]
            originaltitle = re.sub('(?:\(|\s)\d{4}.+', '', t).strip()
            originaltitle = re.sub('\!|\?|\.', '', originaltitle)
            
            post = {'title': '',
                    'original_title': title,
                    'director': '',
                    'writer': '',
                    'cast': '',
                    'year_min': years[0],
                    'year_max': years[1],
                    'gameplay_min': '',
                    'gameplay_max': '',
                    'imdb_min': '1',
                    'imdb_max': '10',
                    'conds': '2',
                    'location': 'movies'}
            post = urllib.urlencode(post)
            result = client.request(self.search_link, post=post)
            if 'id="errorline"' in result: raise Exception()
                       
            result = result.rsplit('"section"', 1)[1].split('"footer"')[0]
            result = client.parseDOM(result, 'a', ret='href')
            for a in result:
                query = urlparse.urljoin(self.base_link, a)
                query = client.replaceHTMLCodes(query)
                query = query.encode('utf-8')
                page_src = client.request(query)
                try: page_src = page_src.decode('iso-8859-1').encode('utf8')
                except: pass
                if 'imdb.com/title/tt' in page_src:                                                 
                    imdb_id = re.compile('imdb.com/title/(tt[0-9]+)').findall(page_src)[0]
                    if imdb_id == imdb:
                        url = client.parseDOM(page_src, 'table', attrs={'class': 'download'})[0]
                        return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url == None: return sources
            result = url.replace('\n','')
            result = re.compile('src.+?flags/([^\.]+).+?center">([^<]+)<.+?center">([^<]+).+?\s*</td.+?center">(.+?)<').findall(result)
            
            locDict = [(i.rsplit('.', 1)[0], i) for i in hostDict]
                            
            for i in result:
                try:     
                    host = i[2].split()[0].rsplit('.', 1)[0].strip().lower()
                    try: host = host.split('(')[0].strip()
                    except: pass
                    host = [x[1] for x in locDict if host == x[0]][0]
                    if not host in hostDict: raise Exception()
                    host = client.replaceHTMLCodes(host)
                    host = host.encode('utf-8')
                    if i[0] == 'hu-hu': lang = '[COLOR green]SZINKRON[/COLOR]'
                    elif not i[0] == 'hu-hu' and '-hu' in i[0] : lang = 'FELIRAT'
                    else: lang = 'NF'
                    if 'DVD' in i[1] or 'BD-Rip' in i[1]: quality = 'SD'
                    elif 'Mozis' in i[1]: quality = 'CAM'
                    else: quality = 'SD'
                    if 'http' in i[3]: url = re.search('<a href="?\'?([^"\'>]*)', i[3]).group(1)
                    else: url = re.search('rev\s*="?([0-9]+)', i[3]).group(1)
                    url = client.replaceHTMLCodes(url)
                    url = url.encode('utf-8')
                    sources.append({'source': host, 'quality': quality, 'lang': lang, 'provider': 'Cinemalive', 'url': url, 'direct': False, 'debridonly': False})
                except:
                    pass
            return sources
        except:
            return sources


    def resolve(self, url):
        try:
            if url.startswith('http'): 
                return url   
            else:
                post = urllib.urlencode({'queryString': '[object HTMLInputElement]'})
                query = urlparse.urljoin(self.base_link, '/includes/mov.php?id=' + url)
                result = client.request(query, post=post)
            
            url = client.parseDOM(result, 'iframe', ret='src')[0]
            url = client.replaceHTMLCodes(url)
            url = url.encode('utf-8')
            return url
        except:
            return
        

class NoRedirection(urllib2.HTTPErrorProcessor):
        def http_response(self, request, response):
            return response