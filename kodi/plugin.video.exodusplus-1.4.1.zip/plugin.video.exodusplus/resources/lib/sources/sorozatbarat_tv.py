# -*- coding: utf-8 -*-

import re,urllib,urllib2,urlparse
from resources.lib.modules import client

class source:
    def __init__(self):
        self.domains = ['sorozat-barat.com']
        self.base_link = 'http://www.sorozat-barat.com'
        self.host_link = 'http://www.filmorias.com'
        self.search_link = 'http://www.sorozat-barat.com/video/search?s='

    def tvshow(self, imdb, tvdb, tvshowtitle, year):
        try:                 
            url = None
            result = None
            tvshowtitle = tvshowtitle.replace(' ', '+')
            query = self.search_link + tvshowtitle
                       
            try:                     
                result = client.request(query, output='geturl')
                if 'search?s' in result: raise Exception()
                page_src = client.request(result)
                if 'imdb.com/title/tt' in page_src:
                        imdb_id = re.compile('imdb.com/title/(tt[0-9]+)/').findall(page_src)[0]
                        if imdb_id == imdb: url = result          
                        return url             
            except:
                pass
            
            try:                     
                if url != None: raise Exception()               
                result = client.request(query)
                if 'nem tal\xc3\xa1lhat\xc3\xb3' in result: return
                seriesid = re.compile('seriesid=([^"]+)">([^<]+)').findall(result)
                for a, b in seriesid:
                    query = self.base_link + '/video/series/' + a
                    page_src = client.request(query)
                    if 'imdb.com/title/tt' in page_src:
                        imdb_id = re.compile('imdb.com/title/(tt[0-9]+)/').findall(page_src)[0]
                        if imdb_id == imdb: url = self.base_link + '/video/series/' + a              
                        return url                  
            except:
                pass            
        except:
            return
 
    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url == None: return           
            ep_url = None
            season = season.zfill(2)
            episode = episode.zfill(2)           
                                             
            result = client.request(url)
            result = client.parseDOM(result, 'ul', attrs={'class': 'seasons'})
            result = client.parseDOM(result, 'a', ret='href')
            for i in result:
                if season + '_evad' in i:
                    url = self.base_link + i
                    url = client.replaceHTMLCodes(url)

            result = client.request(url)
            result = result.replace('\n', '')
            result = re.compile('s' + season + 'e' + episode + '.+?select/([0-9]+)"').findall(result)[0]
            if result.isdigit():
                ep_url = result
                return ep_url
        except:
            return
    
    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url == None: return sources          
            query = self.host_link + '/video/select/' + url
            result = client.request(query)
            result = client.parseDOM(result, 'table', attrs={'class': 'episodes'})[0]
            result = result.replace('\n','')
            result = re.compile('/flags/(.+?)\..+?<td>(.+?)\..+?href="(.+?)"').findall(result) 
            
            locDict = [(i.rsplit('.', 1)[0], i) for i in hostDict]
                    
            for a, b, c in result:
                try:
                    host = b.strip().lower()
                    host = [x[1] for x in locDict if host == x[0]][0]
                    if not host in hostDict: raise Exception()
                    host = client.replaceHTMLCodes(host)
                    host = host.encode('utf-8')
                    if a == 'hu' or a == 'hu-hu': lang = '[COLOR green]SZINKRON[/COLOR]'
                    elif a == 'en-hu': lang = 'FELIRAT'                   
                    else: lang = 'NF'                        
                    url = self.host_link + c
                    url = client.replaceHTMLCodes(url)
                    url = url.encode('utf-8')
                    sources.append({'source': host, 'quality': 'SD', 'lang': lang, 'provider': 'SorozatBarat', 'url': url, 'direct': False, 'debridonly': False})
                except:
                    pass
            return sources
        except:
            return sources


    def resolve(self, url):
        try:
            result = client.request(url)
            url = client.parseDOM(result, 'puremotion', ret='data-url')[0]
            url = client.replaceHTMLCodes(url)
            url = url.encode('utf-8')
            return url
        except:
            return


