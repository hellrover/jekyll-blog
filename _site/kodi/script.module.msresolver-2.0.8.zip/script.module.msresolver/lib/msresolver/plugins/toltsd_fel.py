# -*- coding: UTF-8 -*-

import re
from msresolver import common
from msresolver.resolver import UrlResolver, ResolverError

class Toltsd_felResolver(UrlResolver):
    name = "toltsd-fel.tk"
    domains = ["toltsd-fel.tk"]
    pattern = '(?://|\.)(toltsd-fel\.tk)/(?:embed|video)/([0-9]+)'

    def __init__(self):
        p = self.get_setting('priority') or 100
        self.priority = int(p)
        self.net = common.Net()
        self.user_agent = common.IE_USER_AGENT
        self.net.set_user_agent(self.user_agent)
        self.headers = {'User-Agent': self.user_agent}

    def get_media_url(self, host, media_id):
        web_url = self.get_url(host, media_id)

        top_url = self.net.http_GET(web_url).content

        direct_url = re.compile('m4v: \'(.+?)\'').findall(top_url)   
        if direct_url:
            return (direct_url[0])
        else:
            ResolverError('File not found')

    def get_url(self, host, media_id):
        return 'http://%s/embed/%s' % (host, media_id)

    def get_host_and_id(self, url):
        r = re.search(self.pattern, url)
        if r:
            return r.groups()
        else:
            return False
    
    def valid_url(self, url, host):
        return re.search(self.pattern, url) or self.name in host
