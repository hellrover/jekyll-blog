# -*- coding: utf-8 -*-
import xbmcaddon,os,requests,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,datetime,base64,os.path

thisAddon = xbmcaddon.Addon(id='plugin.video.magyartv')
thisAddonDir = xbmc.translatePath(thisAddon.getAddonInfo('path')).decode('utf-8')
resourcesdir = xbmc.translatePath(os.path.join(thisAddonDir, 'resources', ''))

##### SETTINGS #####

def viewmode():
    addon_settings = xbmcaddon.Addon()
    mview = int(addon_settings.getSetting('mview'))

    if mview == 0:
        xbmc.executebuiltin('Container.SetViewMode(50)')
    elif mview == 1:
        xbmc.executebuiltin('Container.SetViewMode(500)')

    return

##### SETTINGS #####




def get_page(url):
    """ loads a webpage into a string """
    src = ''

    req = urllib2.Request(url)

    try:
        response = urllib2.urlopen(req)
        chunk = True
        while chunk:
            chunk = response.read(1024)
            src += chunk
        response.close()
    except IOError:
        print 'can\'t open',url 
        return src

    return src

def porthuinfo(channel_id):

    if channel_id != 10000:

        port_url_template = 'http://www.port.hu/pls/w/tv_api.event_list?i_channel_id=%s&i_datetime_from=%s&i_datetime_to=%s'

        today = datetime.datetime.now().strftime("%Y-%m-%d")

        porthu_url = port_url_template % (channel_id, today, today)
        porthu_content = get_page(porthu_url)

        capture = re.compile('"capture":"(.+?)",').findall(porthu_content)
        nowplaying = re.compile('"is_live":true\,"title":"(.+?)"').findall(porthu_content)
        guide = re.compile('start_time":"(.+?)".+?end_time":"(.+?)".+?.+?title":"(.+?)"').findall(porthu_content)

    if not capture:
        c = "http://i.imgur.com/9m7TZNF.png"
    else:
        c = capture[0]

    if not nowplaying:
        n = ""
    else:
        n = ": " + nowplaying[0].decode('iso-8859-1').encode('utf8')

    if not guide:
        g = ""
    else:
        g = ""
        for hr, mnt, title in guide:
            g += ("[B][COLOR green]" +hr + "[/COLOR][/B] " + title + '; ').decode('iso-8859-1').encode('utf8')

    return c, n, g

def refresh_channels():
    addon_settings = xbmcaddon.Addon()
    g = base64.b64decode(requests.get(addon_settings.getSetting('channels')).content)
    f = open(resourcesdir + 'channels.xml','w')
    f.write(g)
    f.close()
    folders()
    return

def folders():

    addon_settings = xbmcaddon.Addon()

    if os.path.isfile(resourcesdir + 'channels.xml') == True:
        f = open(resourcesdir + 'channels.xml','r')
        g = f.read()
        f.close()
    else:
        g = base64.b64decode(requests.get(addon_settings.getSetting('channels')).content)
        f = open(resourcesdir + 'channels.xml','w')
        f.write(g)
        f.close()
        folders()

    match = re.compile('<name>(.+?)</name><url>(.+?)</url><porthu_id>(.+?)</porthu_id>').findall(g)

    if addon_settings.getSetting('porthuinfo') == 'true':
        addDir3('Csatornalista frissítés', '', 5, '', '', '')
        addDir3('[B]M1[/B]' + porthuinfo(1)[1], 'mtv1live', 1, porthuinfo(1)[0], '', porthuinfo(1)[2])
        addDir3('[B]M2[/B]' + porthuinfo(2)[1], 'mtv2live', 1, porthuinfo(2)[0], '', porthuinfo(2)[2])
        addDir3('[B]Duna[/B]' + porthuinfo(6)[1], 'dunalive', 1, porthuinfo(6)[0], '', porthuinfo(6)[2])
        addDir3('[B]Duna World[/B]' + porthuinfo(103)[1], 'dunaworldlive', 1, porthuinfo(103)[0], '', porthuinfo(103)[2])
        addDir3('[B]M4 Sport[/B]' + porthuinfo(290)[1], 'mtv4live', 1, porthuinfo(290)[0], '', porthuinfo(290)[2])

        for name, url, porthu_id in match:
            addDir4('[B]'+name+'[/B]'+porthuinfo(porthu_id)[1], url, 2, porthuinfo(porthu_id)[0], '', porthuinfo(porthu_id)[2])

    else:
        addDir3('Csatornalista frissítés', ' ', 5, '', '', '')
        addDir3('[B]M1[/B]', 'mtv1live', 1, '', '', '')
        addDir3('[B]M2[/B]', 'mtv2live', 1, '', '', '')
        addDir3('[B]Duna[/B]', 'dunalive', 1, '', '', '')
        addDir3('[B]Duna World[/B]', 'dunaworldlive', 1, '', '', '')
        addDir3('[B]M4 Sport[/B]', 'mtv4live', 1, '', '', '')

        for name, url, porthu_id in match:
            addDir4('[B]'+name+'[/B]', url, 2, '', '', '')


def addDir4(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok


def getvideo(name, url, iconimage):
    top_url = 'http://inside.gamaxmedia.hu/player-inside-full?streamid=' + url + '&userid=mtva'
            
    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return

    direct_url = re.compile('file\'[^h]+([^\']+)').findall(url_content)

    videoitem = xbmcgui.ListItem(label=url, thumbnailImage=iconimage)
    videoitem.setInfo(type='Video', infoLabels={'Title': name})
    xbmc.Player().play(direct_url[0], videoitem)

    return

def getvideo2(name, url, iconimage):
    videoitem = xbmcgui.ListItem(label=url, thumbnailImage=iconimage)
    videoitem.setInfo(type='Video', infoLabels={'Title': name})
    xbmc.Player().play(url, videoitem)
    return


def find_read_error(top_url):
    try:
        req = urllib2.Request(top_url, None, {'User-agent' : 'Mozilla/5.0 (Windows; U; Windows NT 5.1; de; rv:1.9.1.5) Gecko/20091102 Firefox/3.5.5',
                                            'Accept-Language': 'hu-HU,hu;q=0.8'})
        url_handler = urllib2.urlopen(req)
        url_content = url_handler.read()
        url_handler.close()
    except:
        url_content = 'HIBA'
        addon = xbmcaddon.Addon()
        addonname = addon.getAddonInfo('name')
        line1 = u'Az internetes adatb\xE1zishoz val\xF3 csatlakoz\xE1s sikertelen!'
        xbmcgui.Dialog().ok(addonname, line1)
        return url_content
    return url_content

def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass

if mode==None or url==None or len(url)<1:
    folders()
elif mode==1:
    getvideo(name, url, iconimage)
elif mode==2:
    getvideo2(name, url, iconimage)
elif mode==5:
    refresh_channels()
    
xbmcplugin.endOfDirectory(int(sys.argv[1]))