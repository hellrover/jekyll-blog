import xbmcaddon

MainBase = 'http://gzoltan.pe.hu/addons/televizija/home.txt'
addon = xbmcaddon.Addon('plugin.video.onlajnTV')