# -*- coding: utf-8 -*-
import xbmcaddon,os,requests,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin

def folders():

    r = requests.get("http://tv2.hu/musoraink/teljes_filmek")
    m = re.compile('cikk_listaelem_nagy.+?<img src="(.+?)".+?\n.+?\n.+?href="(.+?)".+?>(.+?)</a>').findall(r.content)
    for img, url, name in m:
        addDir3('[B][COLOR green]TV2[/COLOR][/B] ' + name, 'http://tv2.hu' + url, 1, img, img, '')

    r = requests.get("http://supertv2.hu/musoraink/teljes_filmek")
    m = re.compile('cikk_listaelem_nagy.+?<img src="(.+?)".+?href="(.+?)".+?>(.+?)<').findall(r.content)
    for img, url, name in m:
        addDir3('[B][COLOR green]SUPERTV2[/COLOR][/B] ' + name, 'http://supertv2.hu' + url, 2, 'http://supertv2.hu' + img, 'http://supertv2.hu' + img, '')

    r = requests.get("http://fem3.hu/musoraink/teljes_filmek")
    m = re.compile('cikk_listaelem_nagy.+?<img src="(.+?)".+?\n.+?\n.+?href="(.+?)".+?>(.+?)</a>').findall(r.content)
    for img, url, name in m:
        addDir3('[B][COLOR green]FEM3[/COLOR][/B] ' + name, 'http://fem3.hu' + url, 2, img, img, '')

    r = requests.get("http://pro4.hu/musoraink/teljes_filmek/")
    m = re.compile('cikk_listaelem_nagy.+?<img src="(.+?)".+?\n.+?\n.+?href="(.+?)".+?>(.+?)</a>').findall(r.content)
    for img, url, name in m:
        addDir3('[B][COLOR green]PRO4[/COLOR][/B] ' + name, 'http://pro4.hu' + url, 2, img, img, '')

def playtv2(url, iconimage, name):
    r = requests.get(url)
    m = re.compile('html5url="(.+?)";').findall(r.content)
    #xbmc.executebuiltin("XBMC.Notification('url','"+m[0]+"')");
    videoitem = xbmcgui.ListItem(label=name, thumbnailImage=iconimage)
    videoitem.setInfo(type='Video', infoLabels={'Title': name})
    xbmc.Player().play(m[0], videoitem)
    return

def playsupertv2(url):
    r = requests.get(url)
    m = re.compile('html5video = \'<video width=".+? height=".+?" controls><source src="(.+)" type="video/mp4;"').findall(r.content)
    videoitem = xbmcgui.ListItem(label=name, thumbnailImage=iconimage)
    videoitem.setInfo(type='Video', infoLabels={'Title': name})
    xbmc.Player().play(m[0], videoitem)
    return

def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass

if mode==None or url==None or len(url)<1:
    folders()
elif mode==1:
    playtv2(url, iconimage, name)
elif mode==2:
    playsupertv2(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))